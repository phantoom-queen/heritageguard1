"""
WSGI configuration for PythonAnywhere deployment.
Place this file in the same directory as app.py and configure the WSGI path
in PythonAnywhere web app settings to point to this file's application object.
"""

import sys
import os

# Add the project directory to the Python path
project_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_dir)

from app import app

# This is the WSGI application object that PythonAnywhere will use
application = app

if __name__ == "__main__":
    app.run()

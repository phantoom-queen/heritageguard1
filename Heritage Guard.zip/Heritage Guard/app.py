from flask import Flask, render_template, request, redirect, url_for, session, flash
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "heritage-guard-secret-2024"

# ---------- In-Memory Data Stores ----------
ARTIFACTS = []
ACTIVITY_LOG = []
WATCHLIST = set()
TEAM_NOTES = []
ILLEGAL_ACTIVITY_REPORTS = []  # Store reports of illegal activities
USERS = {}  # Stores registered users: {"username": {"password": "hash", "role": "role"}}

ROLES = {
    "admin": "System Administrator",
    "archaeologist": "Archaeologist",
    "museum": "Museum Worker",
    "security": "Security Staff",
    "trial": "Trial User",
}

# Seed sample data
SEED_ARTIFACTS = [
    {"code": "HG-1001", "name": "Bronze Dagger", "era": "Late Bronze Age",
     "location": "Dig Site A — Trench 3", "status": "OK",
     "watchlist": True, "notes": "Found near burial chamber.",
     "condition": [], "history": [{"ts": "2024-05-12 09:14", "action": "Registered at dig site"}]},
    {"code": "HG-1002", "name": "Clay Oil Lamp", "era": "Roman",
     "location": "Museum Lab 2", "status": "Broken",
     "watchlist": False, "notes": "Hairline crack on base.",
     "condition": ["Crack on base", "Surface erosion"],
     "history": [{"ts": "2024-05-13 11:02", "action": "Transported to Museum Lab 2"},
                 {"ts": "2024-05-13 14:30", "action": "Marked broken — crack observed"}]},
    {"code": "HG-1003", "name": "Gold Pendant", "era": "Hellenistic",
     "location": "Gallery 4 — Display Case 7", "status": "OK",
     "watchlist": True, "notes": "High-value item. Requires 2-person handling.",
     "condition": [], "history": [{"ts": "2024-05-14 10:00", "action": "Installed in Gallery 4"}]},
    {"code": "HG-1004", "name": "Marble Fragment", "era": "Classical",
     "location": "Storage B — Shelf 12", "status": "Stolen",
     "watchlist": True, "notes": "Reported missing during inventory.",
     "condition": [], "history": [{"ts": "2024-05-15 08:45", "action": "Reported stolen"}]},
    {"code": "HG-1005", "name": "Ceramic Amphora", "era": "Archaic",
     "location": "Dig Site B — Trench 1", "status": "OK",
     "watchlist": False, "notes": "In situ, awaiting extraction.",
     "condition": [], "history": [{"ts": "2024-05-16 13:20", "action": "Documented in situ"}]},
]
for a in SEED_ARTIFACTS:
    ARTIFACTS.append(a)
    if a["watchlist"]:
        WATCHLIST.add(a["code"])

ACTIVITY_LOG.extend([
    {"ts": "2024-05-16 13:20", "user": "Dr. Carter", "role": "Archaeologist",
     "action": "Documented artifact HG-1005 at Dig Site B"},
    {"ts": "2024-05-15 08:45", "user": "Officer Reyes", "role": "Security Staff",
     "action": "Reported HG-1004 as stolen"},
    {"ts": "2024-05-14 10:00", "user": "Ms. Lin", "role": "Museum Worker",
     "action": "Moved HG-1003 to Gallery 4"},
])

# Seed default admin account for system management
USERS["admin"] = {
    "password": generate_password_hash("admin123"),
    "role": "admin"
}

# ---------- Context Processor ----------
@app.context_processor
def inject_globals():
    return dict(ROLES=ROLES)

# ---------- Helpers ----------
def next_code():
    nums = [int(a["code"].split("-")[1]) for a in ARTIFACTS]
    nxt = max(nums) + 1 if nums else 1001
    return f"HG-{nxt}"

def log_action(action):
    role_label = ROLES.get(session.get("role", "trial"), "Trial User")
    ACTIVITY_LOG.insert(0, {
        "ts": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "user": session.get("username", "Guest"),
        "role": role_label,
        "action": action,
    })

def can_edit():
    return session.get("role") in ("archaeologist", "museum", "security")

def is_admin():
    return session.get("role") == "admin"

def can_report_illegal():
    return session.get("role") in ("security", "archaeologist", "museum", "admin")

def can_view_illegal_reports():
    return session.get("role") in ("security", "admin")

# ---------- Auth Routes ----------
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if session.get("username"):
        return redirect(url_for("dashboard"))
        
    if request.method == "POST":
        username = request.form.get("username").strip()
        password = request.form.get("password")
        role = request.form.get("role", "trial")
        
        if not username or not password:
            flash("Username and password are required.", "error")
            return redirect(url_for("register"))
            
        if username in USERS:
            flash("That username is already taken. Please choose another.", "error")
            return redirect(url_for("register"))
            
        USERS[username] = {
            "password": generate_password_hash(password),
            "role": role
        }
        
        session["username"] = username
        session["role"] = role
        log_action(f"Registered a new account as {ROLES[role]}")
        flash(f"Account created successfully! Welcome to Heritage Guard.", "success")
        return redirect(url_for("dashboard"))
        
    return render_template("register.html", roles=ROLES)

@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("username"):
        return redirect(url_for("dashboard"))
        
    if request.method == "POST":
        username = request.form.get("username").strip()
        password = request.form.get("password")
        
        user = USERS.get(username)
        if user and check_password_hash(user["password"], password):
            session["username"] = username
            session["role"] = user["role"]
            log_action("Logged in")
            flash(f"Welcome back, {username}! Logged in as {ROLES[user['role']]}.", "success")
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid username or password. Please try again or register.", "error")
            return redirect(url_for("login"))
            
    return render_template("login.html")

@app.route("/logout")
def logout():
    if "username" in session:
        log_action("Logged out")
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))

# ---------- Protected App Routes ----------
@app.route("/dashboard")
def dashboard():
    if "username" not in session:
        flash("Please log in to access the dashboard.", "warning")
        return redirect(url_for("login"))
        
    stats = {
        "total": len(ARTIFACTS),
        "ok": sum(1 for a in ARTIFACTS if a["status"] == "OK"),
        "broken": sum(1 for a in ARTIFACTS if a["status"] == "Broken"),
        "stolen": sum(1 for a in ARTIFACTS if a["status"] == "Stolen"),
        "watchlist": len(WATCHLIST),
    }
    recent = ACTIVITY_LOG[:5]
    alerts = [a for a in ARTIFACTS if a["status"] in ("Stolen", "Broken") or a["watchlist"]][:4]
    return render_template("dashboard.html", stats=stats, recent=recent, alerts=alerts,
                           role_label=ROLES.get(session["role"]))

@app.route("/artifacts")
def artifacts():
    if "username" not in session:
        flash("Please log in to view artifacts.", "warning")
        return redirect(url_for("login"))
        
    q = request.args.get("q", "").lower()
    status_filter = request.args.get("status", "")
    filtered = ARTIFACTS
    if q:
        filtered = [a for a in filtered if q in a["name"].lower() or q in a["code"].lower()
                    or q in a["location"].lower()]
    if status_filter:
        filtered = [a for a in filtered if a["status"] == status_filter]
    return render_template("artifacts.html", artifacts=filtered, q=q, sf=status_filter)

@app.route("/artifacts/<code>")
def artifact_detail(code):
    if "username" not in session:
        return redirect(url_for("login"))
        
    artifact = next((a for a in ARTIFACTS if a["code"] == code), None)
    if not artifact:
        flash("Artifact not found.", "error")
        return redirect(url_for("artifacts"))
    return render_template("artifact_detail.html", a=artifact, can_edit=can_edit())

@app.route("/artifacts/add", methods=["GET", "POST"])
def add_artifact():
    if "username" not in session or not can_edit():
        flash("You do not have permission to add artifacts.", "error")
        return redirect(url_for("artifacts"))
        
    if request.method == "POST":
        new = {
            "code": next_code(),
            "name": request.form.get("name", "Unnamed"),
            "era": request.form.get("era", "Unknown"),
            "location": request.form.get("location", "Unknown"),
            "status": request.form.get("status", "OK"),
            "watchlist": request.form.get("watchlist") == "on",
            "notes": request.form.get("notes", ""),
            "condition": request.form.getlist("condition") if request.form.get("status") == "Broken" else [],
            "history": [{"ts": datetime.now().strftime("%Y-%m-%d %H:%M"),
                         "action": f"Registered by {session.get('username')}"}],
        }
        ARTIFACTS.append(new)
        if new["watchlist"]:
            WATCHLIST.add(new["code"])
        log_action(f"Registered new artifact {new['code']} ({new['name']})")
        flash(f"Artifact {new['code']} registered successfully!", "success")
        return redirect(url_for("artifact_detail", code=new["code"]))
    return render_template("add_artifact.html", code=next_code())

@app.route("/artifacts/<code>/status", methods=["POST"])
def update_status(code):
    if "username" not in session or not can_edit():
        flash("Permission denied.", "error")
        return redirect(url_for("artifact_detail", code=code))
        
    artifact = next((a for a in ARTIFACTS if a["code"] == code), None)
    if not artifact:
        flash("Artifact not found.", "error")
        return redirect(url_for("artifacts"))
        
    new_status = request.form.get("status")
    location = request.form.get("location")
    note = request.form.get("note", "")
    conditions = request.form.getlist("condition")
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    
    if new_status and new_status != artifact["status"]:
        artifact["status"] = new_status
        artifact["history"].insert(0, {"ts": ts, "action": f"Status changed to {new_status}"})
        log_action(f"Changed {code} status to {new_status}")
    if location and location != artifact["location"]:
        artifact["location"] = location
        artifact["history"].insert(0, {"ts": ts, "action": f"Moved to {location}"})
        log_action(f"Moved {code} to {location}")
    if new_status == "Broken" and conditions:
        artifact["condition"] = conditions
    if note:
        artifact["history"].insert(0, {"ts": ts, "action": f"Note: {note}"})
        
    flash("Artifact updated.", "success")
    return redirect(url_for("artifact_detail", code=code))

@app.route("/watchlist")
def watchlist():
    if "username" not in session:
        return redirect(url_for("login"))
        
    items = [a for a in ARTIFACTS if a["code"] in WATCHLIST]
    return render_template("watchlist.html", items=items)

@app.route("/watchlist/<code>/toggle", methods=["POST"])
def toggle_watchlist(code):
    if "username" not in session or not can_edit():
        flash("Permission denied.", "error")
        return redirect(url_for("artifact_detail", code=code))
        
    if code in WATCHLIST:
        WATCHLIST.remove(code)
        log_action(f"Removed {code} from watchlist")
        flash(f"{code} removed from watchlist.", "info")
    else:
        WATCHLIST.add(code)
        log_action(f"Added {code} to watchlist")
        flash(f"{code} added to watchlist.", "success")
    return redirect(url_for("artifact_detail", code=code))

@app.route("/activity")
def activity_log():
    if "username" not in session:
        return redirect(url_for("login"))
    return render_template("activity_log.html", logs=ACTIVITY_LOG)

@app.route("/reports")
def reports():
    if "username" not in session:
        return redirect(url_for("login"))
        
    by_status = {"OK": 0, "Broken": 0, "Stolen": 0}
    for a in ARTIFACTS:
        by_status[a["status"]] = by_status.get(a["status"], 0) + 1
    by_location = {}
    for a in ARTIFACTS:
        loc = a["location"].split(" — ")[0]
        by_location[loc] = by_location.get(loc, 0) + 1
    problems = [a for a in ARTIFACTS if a["status"] in ("Broken", "Stolen")]
    return render_template("reports.html", by_status=by_status, by_location=by_location,
                           problems=problems, total=len(ARTIFACTS), logs=ACTIVITY_LOG, now=datetime.now().strftime("%Y-%m-%d %H:%M"))

@app.route("/report-illegal", methods=["GET", "POST"])
def report_illegal_activity():
    if "username" not in session:
        flash("Please log in to report illegal activities.", "warning")
        return redirect(url_for("login"))
    
    if not can_report_illegal():
        flash("You do not have permission to report illegal activities.", "error")
        return redirect(url_for("dashboard"))
    
    if request.method == "POST":
        report = {
            "id": len(ILLEGAL_ACTIVITY_REPORTS) + 1,
            "reported_by": session.get("username"),
            "reporter_role": session.get("role"),
            "ts": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "title": request.form.get("title", "Untitled"),
            "description": request.form.get("description", ""),
            "location": request.form.get("location", ""),
            "severity": request.form.get("severity", "medium"),
            "status": "open",
            "notes": []
        }
        ILLEGAL_ACTIVITY_REPORTS.insert(0, report)
        log_action(f"Reported illegal activity: {report['title']}")
        flash("Illegal activity report submitted successfully.", "success")
        return redirect(url_for("dashboard"))
    
    return render_template("report_illegal.html")

@app.route("/illegal-reports")
def illegal_reports():
    if "username" not in session:
        flash("Please log in to view reports.", "warning")
        return redirect(url_for("login"))
    
    if not can_view_illegal_reports():
        flash("You do not have permission to view illegal activity reports.", "error")
        return redirect(url_for("dashboard"))
    
    # Filter by status if requested
    status_filter = request.args.get("status", "")
    severity_filter = request.args.get("severity", "")
    
    filtered_reports = ILLEGAL_ACTIVITY_REPORTS
    if status_filter:
        filtered_reports = [r for r in filtered_reports if r["status"] == status_filter]
    if severity_filter:
        filtered_reports = [r for r in filtered_reports if r["severity"] == severity_filter]
    
    return render_template("illegal_reports.html", reports=filtered_reports)

@app.route("/illegal-reports/<int:report_id>/status", methods=["POST"])
def update_report_status(report_id):
    if "username" not in session or not is_admin():
        flash("Permission denied.", "error")
        return redirect(url_for("dashboard"))
    
    report = next((r for r in ILLEGAL_ACTIVITY_REPORTS if r["id"] == report_id), None)
    if not report:
        flash("Report not found.", "error")
        return redirect(url_for("illegal_reports"))
    
    new_status = request.form.get("status")
    note = request.form.get("note", "")
    
    if new_status:
        report["status"] = new_status
        log_action(f"Updated illegal activity report {report_id} status to {new_status}")
    
    if note:
        report["notes"].append({
            "user": session.get("username"),
            "ts": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "text": note
        })
        log_action(f"Added note to illegal activity report {report_id}")
    
    flash("Report updated.", "success")
    return redirect(url_for("illegal_reports"))

@app.route("/admin/dashboard")
def admin_dashboard():
    if "username" not in session or not is_admin():
        flash("You do not have permission to access the admin dashboard.", "error")
        return redirect(url_for("dashboard"))
    
    total_users = len(USERS)
    total_artifacts = len(ARTIFACTS)
    total_reports = len(ILLEGAL_ACTIVITY_REPORTS)
    open_reports = sum(1 for r in ILLEGAL_ACTIVITY_REPORTS if r["status"] == "open")
    
    stats = {
        "total_users": total_users,
        "total_artifacts": total_artifacts,
        "total_reports": total_reports,
        "open_reports": open_reports,
    }
    
    recent_reports = ILLEGAL_ACTIVITY_REPORTS[:5]
    recent_activity = ACTIVITY_LOG[:10]
    
    return render_template("admin_dashboard.html", stats=stats, recent_reports=recent_reports,
                          recent_activity=recent_activity)

@app.route("/about")
def about():
    return render_template("about.html")

if __name__ == "__main__":
    app.run(debug=False)
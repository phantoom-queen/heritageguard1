"""
Production configuration for Heritage Guard Flask application.
Modify app.py to use this configuration in production environments.
"""

import os
from datetime import timedelta

class Config:
    """Base configuration"""
    # Session and security
    SECRET_KEY = os.environ.get('SECRET_KEY', 'heritage-guard-secret-2024')
    SESSION_COOKIE_SECURE = True  # Set to True in production with HTTPS
    SESSION_COOKIE_HTTPONLY = True
    PERMANENT_SESSION_LIFETIME = timedelta(hours=24)
    
    # Database (if using one in the future)
    # SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL', 'sqlite:///heritage_guard.db')
    # SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Logging
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')

class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    TESTING = False
    SESSION_COOKIE_SECURE = False

class ProductionConfig(Config):
    """Production configuration for PythonAnywhere"""
    DEBUG = False
    TESTING = False
    SESSION_COOKIE_SECURE = True

class TestingConfig(Config):
    """Testing configuration"""
    DEBUG = True
    TESTING = True
    SESSION_COOKIE_SECURE = False

def get_config():
    """Get appropriate configuration based on environment"""
    env = os.environ.get('FLASK_ENV', 'production')
    config_map = {
        'development': DevelopmentConfig,
        'production': ProductionConfig,
        'testing': TestingConfig,
    }
    return config_map.get(env, ProductionConfig)

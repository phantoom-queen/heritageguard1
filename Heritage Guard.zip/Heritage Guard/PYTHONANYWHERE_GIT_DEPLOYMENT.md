# Heritage Guard - Complete PythonAnywhere Deployment Guide (Using GitHub & Git Clone)

## Overview
This guide walks you through deploying the Heritage Guard Flask application to PythonAnywhere directly from GitHub using `git clone`.

---

## **Phase 1: GitHub Setup (Local Machine)**

### Step 1.1: Initialize Git Repository Locally
```bash
cd "C:\Users\Ella Zawadi\Desktop\Heritage Guard"
git init
```

### Step 1.2: Configure Git (if not already configured)
```bash
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"
```

### Step 1.3: Create .gitignore (already created in project)
The `.gitignore` file is already in your project to exclude unnecessary files.

### Step 1.4: Add All Project Files to Git
```bash
git add .
```

### Step 1.5: Create Initial Commit
```bash
git commit -m "Initial commit: Heritage Guard artifact management system"
```

### Step 1.6: Create GitHub Repository
1. Go to **https://github.com/new**
2. Sign in (create account if needed)
3. Fill in repository details:
   - **Repository name**: `heritage-guard` (or your preferred name)
   - **Description**: "Artifact management system for archaeologists and museum workers"
   - **Visibility**: Choose Public or Private
4. Click **Create repository**
5. **Do NOT** initialize with README (you already have one)

### Step 1.7: Push Code to GitHub
After creating the repository, GitHub will show you commands. Run these:

```bash
git remote add origin https://github.com/YOUR_USERNAME/heritage-guard.git
git branch -M main
git push -u origin main
```

**Replace `YOUR_USERNAME` with your actual GitHub username**

### Step 1.8: Verify Push
- Go to your GitHub repository URL: `https://github.com/YOUR_USERNAME/heritage-guard`
- You should see all your project files

---

## **Phase 2: PythonAnywhere Setup**

### Step 2.1: Create PythonAnywhere Account
1. Go to **https://www.pythonanywhere.com**
2. Click **Sign up**
3. Choose a free or paid account
4. Create your account
5. Verify your email

### Step 2.2: Log into PythonAnywhere Dashboard
- Go to **https://www.pythonanywhere.com/user/YOUR_USERNAME/dashboards/web/**

---

## **Phase 3: Clone Repository on PythonAnywhere**

### Step 3.1: Open PythonAnywhere Bash Console
1. Click **Consoles** tab (top menu)
2. Click **Bash** (to open new bash console)
3. Wait for console to load

### Step 3.2: Navigate to Home Directory
```bash
cd ~
```

### Step 3.3: Clone Repository from GitHub
```bash
git clone https://github.com/YOUR_USERNAME/heritage-guard.git
```

**Replace `YOUR_USERNAME` with your GitHub username**

**Note**: If your repository is private, you'll need to:
- Use SSH key or
- Generate a personal access token and use:
  ```bash
  git clone https://YOUR_USERNAME:YOUR_TOKEN@github.com/YOUR_USERNAME/heritage-guard.git
  ```

### Step 3.4: Verify Clone Success
```bash
ls -la
```
You should see the `heritage-guard` directory listed.

### Step 3.5: Navigate to Project Directory
```bash
cd heritage-guard
ls -la
```
You should see: `app.py`, `wsgi.py`, `requirements.txt`, `static/`, `templates/`, etc.

---

## **Phase 4: Create Virtual Environment**

### Step 4.1: Create Virtual Environment
```bash
mkvirtualenv --python=/usr/bin/python3.10 hg_env
```

This creates a virtual environment named `hg_env` using Python 3.10.

**Output should show:**
```
Running virtualenv with interpreter /usr/bin/python3.10
...
New python executable in /home/username/.virtualenvs/hg_env/bin/python3.10
(hg_env)$
```

### Step 4.2: Verify Virtualenv Creation
```bash
which python
```
You should see the virtualenv path like `/home/username/.virtualenvs/hg_env/bin/python`

### Step 4.3: Install Dependencies
```bash
pip install -r requirements.txt
```

**Expected output:**
```
Successfully installed Flask-2.3.3 Werkzeug-2.3.7
```

### Step 4.4: Verify Installation
```bash
pip list
```
Check that `Flask` and `Werkzeug` are installed.

---

## **Phase 5: Configure WSGI Application**

### Step 5.1: Go to Web Tab
1. Click **Web** tab (top menu)
2. Click **Add a new web app**

### Step 5.2: Choose Manual Configuration
- Select **Manual configuration**
- Select **Python 3.10**
- Click **Next**

### Step 5.3: Configure WSGI File
1. In the Web tab, under **"WSGI configuration file"**, you'll see a path
2. Click on the path to open the WSGI file editor
3. Replace the entire content with:

```python
import sys
import os

# Add your project directory to the path
path = '/home/YOUR_USERNAME/heritage-guard'
if path not in sys.path:
    sys.path.append(path)

# Import the application
from wsgi import application
```

**Replace `YOUR_USERNAME` with your PythonAnywhere username**

4. Click **Save**

### Step 5.4: Verify Virtualenv Path
1. Scroll down in the Web tab to **"Virtualenv"** section
2. Click in the field and enter:
   ```
   /home/YOUR_USERNAME/.virtualenvs/hg_env
   ```
3. Click the checkmark or press Enter

**The path should turn green** ✓

---

## **Phase 6: Configure Static Files**

### Step 6.1: Map Static Files
1. In the Web tab, scroll to **"Static files:"** section
2. Click **"Add a new static files mapping"**
3. Fill in:
   - **URL**: `/static/`
   - **Directory**: `/home/YOUR_USERNAME/heritage-guard/static`
4. Click the checkmark

### Step 6.2: Verify CSS File
```bash
# From bash console in your project directory
ls -la static/css/
```
You should see `style.css` listed.

---

## **Phase 7: Configure Templates & App Settings**

### Step 7.1: Update Secret Key (Important!)
It's recommended to change the secret key. Edit the WSGI file or app.py:

**Option A: Via Environment Variable (Recommended)**
1. In Web tab, scroll to **"Environment variables"**
2. Click **Add a new variable**
3. Name: `SECRET_KEY`
4. Value: Create a random string (e.g., using `python -c "import secrets; print(secrets.token_hex(32))"`)

**Option B: Update app.py directly**
1. In bash console:
   ```bash
   cd ~/heritage-guard
   nano app.py
   ```
2. Find line: `app.secret_key = "heritage-guard-secret-2024"`
3. Change to: `app.secret_key = "your-new-random-secret-key-here"`
4. Press `Ctrl+X`, then `Y`, then `Enter` to save

### Step 7.2: Commit Changes Back to GitHub (if you made any)
```bash
cd ~/heritage-guard
git add .
git commit -m "Updated configuration for production"
git push origin main
```

---

## **Phase 8: Enable & Test the Web App**

### Step 8.1: Reload Web App
1. Go to **Web** tab
2. At the top, click the green **Reload** button
3. Wait for it to finish (should take 10-30 seconds)

### Step 8.2: Access Your Application
1. At the top of the Web tab, you'll see your domain:
   ```
   https://YOUR_USERNAME.pythonanywhere.com
   ```
2. Click the link or paste it into your browser

### Step 8.3: Test Basic Functionality
- [ ] Page loads successfully
- [ ] Home page displays
- [ ] CSS styling is applied
- [ ] Can navigate to Login page
- [ ] Can create new account
- [ ] Can log in with credentials
- [ ] Dashboard loads with data
- [ ] Can view artifacts
- [ ] Can access admin features (login as admin, password: admin123)

---

## **Phase 9: Troubleshooting**

### Issue: 500 Error or "Internal Server Error"

**Solution:**
1. Check error logs:
   ```bash
   tail -f /var/log/YOUR_USERNAME.pythonanywhere.com.error.log
   ```
2. Common issues:
   - **Import error**: Missing dependencies → Run `pip install -r requirements.txt`
   - **WSGI path incorrect**: Check Web tab configuration
   - **Static files not found**: Verify path mapping in Web tab

### Issue: Static Files (CSS) Not Loading

**Solution:**
1. Verify static file mapping in Web tab
2. Check file exists:
   ```bash
   ls -la ~/heritage-guard/static/css/style.css
   ```
3. Clear browser cache (Ctrl+Shift+Del)
4. Check browser console (F12) for 404 errors

### Issue: "ModuleNotFoundError" for Flask or Werkzeug

**Solution:**
```bash
source ~/.virtualenvs/hg_env/bin/activate
pip install -r requirements.txt
deactivate
```
Then reload the web app.

### Issue: Database/Data Resets

**Note**: This is expected behavior! Your app uses in-memory storage.
- All data resets when app reloads or server restarts
- To persist data, add SQLite database (see Phase 10)

### Issue: Admin Login Fails

**Solution:**
- Default credentials: username=`admin`, password=`admin123`
- Make sure you haven't changed the USERS seeding in app.py
- Check USERS dictionary initialization

---

## **Phase 10: Set Up Persistent Database (Optional but Recommended)**

### Step 10.1: Add Database Support to app.py

This would require refactoring the in-memory data stores to use SQLite. See the supplementary guide: `DATABASE_SETUP.md`

### Step 10.2: Update requirements.txt
Add database library:
```
Flask-SQLAlchemy==3.0.5
```

### Step 10.3: Push Changes to GitHub
```bash
cd ~/heritage-guard
git add requirements.txt
git commit -m "Add SQLAlchemy for database support"
git push origin main
```

---

## **Phase 11: Ongoing Maintenance**

### Pulling Updates from GitHub
When you update code locally and push to GitHub, pull on PythonAnywhere:

```bash
cd ~/heritage-guard
git pull origin main
# Reload web app from Web tab
```

### Checking Logs
```bash
# Error log
tail -f /var/log/YOUR_USERNAME.pythonanywhere.com.error.log

# Server log
tail -f /var/log/YOUR_USERNAME.pythonanywhere.com.server.log
```

### Monitoring Activity
1. Check **Web** tab → **"Access log"**
2. Review activity in Heritage Guard's Activity Log feature

### Updating Dependencies
```bash
source ~/.virtualenvs/hg_env/bin/activate
pip install --upgrade -r requirements.txt
deactivate
# Then reload web app
```

---

## **Phase 12: Custom Domain (Optional)**

### Step 12.1: Add Custom Domain
1. In Web tab, click **"Add a domain"**
2. Enter your custom domain (e.g., `heritage-guard.com`)
3. Configure DNS records to point to PythonAnywhere

### Step 12.2: Enable HTTPS
1. In Web tab, enable **"Force HTTPS to SSL"**
2. PythonAnywhere provides free SSL certificates

---

## **Quick Reference: Key PythonAnywhere Paths**

| Item | Path |
|------|------|
| Project Directory | `/home/YOUR_USERNAME/heritage-guard/` |
| Virtual Environment | `/home/YOUR_USERNAME/.virtualenvs/hg_env/` |
| Error Log | `/var/log/YOUR_USERNAME.pythonanywhere.com.error.log` |
| Web Configuration | Web tab in dashboard |
| Bash Console | Consoles → Bash |
| Domain | `https://YOUR_USERNAME.pythonanywhere.com` |

---

## **Helpful Commands**

```bash
# Activate virtualenv
source ~/.virtualenvs/hg_env/bin/activate

# Deactivate virtualenv
deactivate

# Update from GitHub
cd ~/heritage-guard && git pull origin main

# Check Python version
python --version

# List installed packages
pip list

# Install/upgrade single package
pip install --upgrade Flask

# Check if file exists
test -f ~/heritage-guard/app.py && echo "File exists" || echo "File not found"

# View file content
cat ~/heritage-guard/app.py | head -20

# Edit file
nano ~/heritage-guard/app.py

# File permissions
chmod 755 ~/heritage-guard/static/
```

---

## **Success Checklist**

- [ ] Repository created on GitHub
- [ ] All code pushed to GitHub
- [ ] PythonAnywhere account created
- [ ] Repository cloned in PythonAnywhere
- [ ] Virtual environment created and activated
- [ ] Dependencies installed from requirements.txt
- [ ] WSGI file configured correctly
- [ ] Virtualenv path set in Web tab
- [ ] Static files mapped in Web tab
- [ ] Web app reloaded successfully
- [ ] Website loads at YOUR_USERNAME.pythonanywhere.com
- [ ] Can login (test with admin/admin123)
- [ ] CSS styling displays correctly
- [ ] Admin features accessible

---

## **Additional Resources**

- PythonAnywhere Help: https://www.pythonanywhere.com/help/
- PythonAnywhere Web App Setup: https://www.pythonanywhere.com/web_app_setup/
- GitHub Cloning: https://docs.github.com/en/repositories/creating-and-managing-repositories/cloning-a-repository
- Flask Documentation: https://flask.palletsprojects.com/

---

## **Support & Debugging**

If you encounter issues:
1. **Check error logs** in PythonAnywhere
2. **Verify paths** - use `ls -la` to confirm files exist
3. **Test locally first** - ensure app runs on your machine
4. **Review WSGI configuration** - common source of errors
5. **Check virtualenv activation** - dependencies must be installed there

For more help:
- PythonAnywhere Forums: https://www.pythonanywhere.com/forums/
- GitHub Discussions: https://github.com/YOUR_USERNAME/heritage-guard/discussions

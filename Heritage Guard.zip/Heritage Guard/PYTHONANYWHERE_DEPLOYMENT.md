# Heritage Guard - PythonAnywhere Deployment Guide

## Overview
This guide walks you through deploying the Heritage Guard Flask application to PythonAnywhere.

## Prerequisites
- A PythonAnywhere account (https://www.pythonanywhere.com)
- This project code ready for upload

## Step-by-Step Deployment

### 1. **Upload Project Files**
   - Log in to PythonAnywhere
   - Go to **Files** tab
   - Create a new directory (e.g., `/home/your_username/heritage-guard/`)
   - Upload all project files:
     - `app.py`
     - `wsgi.py`
     - `requirements.txt`
     - `static/` folder with all CSS files
     - `templates/` folder with all HTML files

### 2. **Create a Virtual Environment**
   - In PythonAnywhere console, navigate to your project directory:
     ```bash
     cd ~/heritage-guard
     ```
   - Create a virtual environment:
     ```bash
     mkvirtualenv --python=/usr/bin/python3.10 hg_env
     ```
   - Activate it:
     ```bash
     workon hg_env
     ```
   - Install dependencies:
     ```bash
     pip install -r requirements.txt
     ```

### 3. **Configure Web App**
   - Go to **Web** tab on the PythonAnywhere dashboard
   - Click **Add a new web app**
   - Choose "Manual configuration"
   - Select Python 3.10 (or your preferred version)
   - After creation, configure the WSGI file:
     - In the Web tab, under "WSGI configuration file", click the link
     - Edit the file to point to your project:
       ```python
       import sys
       path = '/home/your_username/heritage-guard'
       if path not in sys.path:
           sys.path.append(path)
       from wsgi import application
       ```

### 4. **Configure Static Files**
   - In the **Web** tab, scroll to "Static files" section
   - Add a static file mapping:
     - URL: `/static/`
     - Directory: `/home/your_username/heritage-guard/static`
   - Reload the web app

### 5. **Configure Environment Variables (Optional)**
   - For production, consider:
     - Setting a secure SECRET_KEY environment variable instead of hardcoding
     - Use PythonAnywhere's web app settings to set environment variables
   - Or modify `app.py` to use:
     ```python
     import os
     app.secret_key = os.environ.get('SECRET_KEY', 'heritage-guard-secret-2024')
     ```

### 6. **Reload the Web App**
   - Go to **Web** tab
   - Click the green **Reload** button for your domain
   - Visit your domain (e.g., `your_username.pythonanywhere.com`)

## Important Notes

### Data Persistence
⚠️ **Current Limitation**: The app stores data in-memory (Python variables). This means:
- All data will reset when the app is reloaded or server restarts
- For production, consider adding a database (SQLite, PostgreSQL)

To add persistence, modify `app.py` to use:
- SQLite3 (easiest for small projects)
- PostgreSQL (recommended for production)
- MySQL (also available on PythonAnywhere)

### File Paths
- Ensure `static/` and `templates/` directories are in the correct locations
- Verify permissions are set correctly (typically 755 for directories, 644 for files)

### Debugging
- Check error logs in PythonAnywhere **Web** tab
- Use the **Bash console** to test commands
- Monitor logs in real-time with:
  ```bash
  tail -f /var/log/your_username.pythonanywhere.com.error.log
  ```

### Security Recommendations
1. Change the hardcoded `SECRET_KEY` in `app.py`:
   ```python
   app.secret_key = os.environ.get('SECRET_KEY', 'change-me-in-production')
   ```
2. Set the environment variable in PythonAnywhere web app settings
3. Consider HTTPS (PythonAnywhere provides free SSL certificates)

### Custom Domain
- To use a custom domain, see PythonAnywhere's domain configuration guide
- Ensure DNS records point to PythonAnywhere
- Configure SSL certificate for your domain

## Troubleshooting

| Issue | Solution |
|-------|----------|
| 500 Error | Check error log in Web tab; ensure WSGI path is correct |
| Static files not loading | Verify static file mapping in Web tab points to correct directory |
| Import errors | Ensure `requirements.txt` dependencies are installed in virtualenv |
| Session data lost | This is expected with in-memory storage; add database for persistence |

## Next Steps
1. Add a database for data persistence
2. Set up automated backups
3. Monitor error logs regularly
4. Consider adding email notifications for important events

# PythonAnywhere Deployment - Quick Start Checklist

## 🚀 Before You Start
- [ ] Create GitHub account (https://github.com)
- [ ] Create PythonAnywhere account (https://www.pythonanywhere.com)
- [ ] Have Git installed on your local machine
- [ ] Have SSH key or Personal Access Token for GitHub (if private repo)

---

## 📋 LOCAL MACHINE (5-10 minutes)

### Git Setup
```bash
cd "C:\Users\Ella Zawadi\Desktop\Heritage Guard"
git init
git config --global user.name "Your Name"
git config --global user.email "your@email.com"
git add .
git commit -m "Initial commit"
```

### GitHub Setup
1. Go to https://github.com/new
2. Create new repository: `heritage-guard`
3. Run these commands:
```bash
git remote add origin https://github.com/YOUR_USERNAME/heritage-guard.git
git branch -M main
git push -u origin main
```

---

## 🌐 PYTHONANYWHERE SETUP (15-20 minutes)

### 1️⃣ Open Bash Console
- Login to PythonAnywhere
- Click **Consoles** tab
- Click **Bash**

### 2️⃣ Clone Repository
```bash
cd ~
git clone https://github.com/YOUR_USERNAME/heritage-guard.git
cd heritage-guard
ls -la
```

### 3️⃣ Create Virtual Environment
```bash
mkvirtualenv --python=/usr/bin/python3.10 hg_env
pip install -r requirements.txt
```

### 4️⃣ Configure WSGI
1. Click **Web** tab
2. Click **Add a new web app**
3. Select **Manual configuration** → **Python 3.10**
4. Click on WSGI file path to edit
5. Replace content with:
```python
import sys
path = '/home/YOUR_USERNAME/heritage-guard'
if path not in sys.path:
    sys.path.append(path)
from wsgi import application
```
6. Save

### 5️⃣ Set Virtualenv Path
- In **Web** tab, find **Virtualenv** section
- Enter: `/home/YOUR_USERNAME/.virtualenvs/hg_env`
- Press Enter (should turn green)

### 6️⃣ Add Static Files Mapping
- Click **"Add a new static files mapping"**
- URL: `/static/`
- Directory: `/home/YOUR_USERNAME/heritage-guard/static`

### 7️⃣ Reload Web App
- Click green **Reload** button at top of Web tab
- Wait for it to complete

### 8️⃣ Test Your Site
- Click your domain link: `https://YOUR_USERNAME.pythonanywhere.com`
- Test login: admin / admin123

---

## ✅ Verification Tests

| Test | How | Expected Result |
|------|-----|-----------------|
| Site Loads | Visit domain | Index page displays |
| CSS Works | Check styling | Page is styled (not plain HTML) |
| Login Works | admin / admin123 | Dashboard loads |
| Artifacts Load | Click Artifacts | List of artifacts displays |
| Admin Dashboard | Admin only | Admin dashboard page loads |

---

## 🔧 Troubleshooting

| Problem | Solution |
|---------|----------|
| 500 Error | Check error log: `tail -f /var/log/YOUR_USERNAME.pythonanywhere.com.error.log` |
| CSS Not Loading | Verify static files mapping in Web tab |
| Module Not Found | Run: `source ~/.virtualenvs/hg_env/bin/activate` then `pip install -r requirements.txt` |
| Git Clone Fails | Use SSH key or Personal Access Token if private repo |
| Data Resets | Normal - app uses in-memory storage. Add database for persistence. |

---

## 🔄 Updating After Changes

When you update code locally:
```bash
git add .
git commit -m "Your message"
git push origin main
```

On PythonAnywhere:
```bash
cd ~/heritage-guard
git pull origin main
```
Then reload web app from Web tab.

---

## 📚 File Locations on PythonAnywhere

```
/home/YOUR_USERNAME/
├── heritage-guard/              (Your project)
│   ├── app.py
│   ├── wsgi.py
│   ├── requirements.txt
│   ├── static/
│   │   └── css/
│   │       └── style.css
│   └── templates/
│       ├── base.html
│       ├── dashboard.html
│       └── ...
│
└── .virtualenvs/
    └── hg_env/                  (Your virtual environment)
        └── bin/
            └── python
```

---

## 🎯 One-Liner Commands

### Activate virtual environment
```bash
source ~/.virtualenvs/hg_env/bin/activate
```

### Check if dependencies installed
```bash
pip list | grep -i flask
```

### View recent errors
```bash
tail -20 /var/log/YOUR_USERNAME.pythonanywhere.com.error.log
```

### Restart app
```bash
# From Web tab, click Reload button
```

### Git status
```bash
cd ~/heritage-guard && git status
```

---

## 🆘 Emergency Debugging

If site shows 500 error:
```bash
cd ~/heritage-guard
source ~/.virtualenvs/hg_env/bin/activate
python app.py  # Test if app runs
```

Then check error log to see specific error messages.

---

## ⚠️ Important Notes

1. **Change Admin Password After Deployment**
   - Current: admin / admin123
   - Change in PythonAnywhere dashboard settings

2. **Data Loss on Reload**
   - All data stored in memory is lost when app reloads
   - Add database for production use

3. **Free Account Limitations**
   - 512MB disk space
   - Limited CPU
   - Site may sleep if inactive

4. **HTTPS is FREE**
   - Enable in Web tab for security

---

## 📞 Support Links

- PythonAnywhere Help: https://www.pythonanywhere.com/help/
- Git Documentation: https://git-scm.com/doc
- Flask Help: https://flask.palletsprojects.com/
- This Project Guide: PYTHONANYWHERE_GIT_DEPLOYMENT.md

# Heritage Guard - Pre-Deployment Checklist

## Files Created for Deployment ✓
- [x] `requirements.txt` - Python dependencies
- [x] `wsgi.py` - WSGI entry point for PythonAnywhere
- [x] `config.py` - Production configuration (optional but recommended)
- [x] `PYTHONANYWHERE_DEPLOYMENT.md` - Detailed deployment guide
- [x] `.gitignore` - Version control ignore file

## Code Changes ✓
- [x] Modified `app.py` to use `debug=False` for production

## Pre-Deployment Verification

### Local Testing
- [ ] Test the application locally:
  ```bash
  python app.py
  ```
- [ ] Verify all routes work (register, login, artifacts, dashboard, etc.)
- [ ] Test static files load (CSS)
- [ ] Test file uploads/operations if any

### Structure Verification
- [ ] Ensure `static/` folder exists with all CSS files
- [ ] Ensure `templates/` folder exists with all HTML files
- [ ] Check all imports in `app.py` are correct

### Security
- [ ] Review hardcoded `SECRET_KEY` - plan to change after deployment
- [ ] Check for sensitive data in code (passwords, API keys, etc.)
- [ ] Verify input validation is in place

## PythonAnywhere Deployment Steps

### Account Setup
- [ ] Create/log into PythonAnywhere account
- [ ] Have your username ready

### Upload Phase
- [ ] Upload all files to PythonAnywhere `/home/username/heritage-guard/`
- [ ] Verify folder structure matches local setup

### Environment Setup
- [ ] Create virtual environment
- [ ] Install dependencies from `requirements.txt`
- [ ] Confirm Flask and Werkzeug installed correctly

### Web App Configuration
- [ ] Add new web app in Web tab
- [ ] Select Python 3.10 (or later)
- [ ] Point WSGI file to: `/home/username/heritage-guard/wsgi.py`
- [ ] Configure static files mapping:
  - URL: `/static/`
  - Directory: `/home/username/heritage-guard/static`

### Post-Deployment
- [ ] Reload web app
- [ ] Visit your domain to verify it loads
- [ ] Test main functionality (register, login, artifacts)
- [ ] Check browser console for any JavaScript errors
- [ ] Verify CSS is loading correctly

### Monitoring
- [ ] Bookmark error log location
- [ ] Set up a monitoring routine (check logs daily initially)
- [ ] Test error handling (try accessing invalid routes)

## Optional Enhancements (Post-Deployment)

### Database Setup
- [ ] Consider adding SQLite or PostgreSQL for data persistence
- [ ] Plan data model migration

### Security Hardening
- [ ] Set environment variable for SECRET_KEY
- [ ] Enable HTTPS certificate
- [ ] Configure custom domain if needed
- [ ] Add rate limiting for API endpoints

### Backup & Monitoring
- [ ] Set up automated backups
- [ ] Configure email alerts for errors
- [ ] Set up uptime monitoring

### Scaling
- [ ] Plan for future features
- [ ] Consider caching strategy
- [ ] Plan database optimization

## Deployment Command Reference

```bash
# SSH into PythonAnywhere console
cd ~/heritage-guard

# Create virtual environment
mkvirtualenv --python=/usr/bin/python3.10 hg_env

# Activate environment
workon hg_env

# Install dependencies
pip install -r requirements.txt

# Test locally (if console testing available)
python app.py

# Check Python version
python --version

# Check installed packages
pip list
```

## Quick Links
- PythonAnywhere: https://www.pythonanywhere.com
- PythonAnywhere Help: https://www.pythonanywhere.com/help/
- Flask Documentation: https://flask.palletsprojects.com/

## Support
For issues during deployment, check:
1. PythonAnywhere error logs (Web tab)
2. Console output in bash console
3. WSGI configuration syntax
4. File paths and permissions
